import os

root = r'C:\Users\86158\Desktop\webshell\train'
path = r'C:\Users\86158\Desktop\webshell\train\train'
files = os.listdir(path)
result = os.path.join(root, 'result')  # 生成最终txt文件(result.txt)的路径

with open(result, 'w', encoding='utf-8-sig') as r:
    for i in range(1, 30):
        print(i)
        #        fname = str(i) + '.txt'
        fname = str(i)
        filename = os.path.join(path, fname)
        with open(filename, 'r', encoding='utf-8-sig') as f:
            for line in f:
                r.writelines(line)
            r.write('\n')
