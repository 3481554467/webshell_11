#方式一
import csv
file=r'D:\workspace\train.csv'

with open(file) as f:
    reader = csv.reader(f)
    rows=[row for row in  reader]
    print(len(rows))

    list1=[]
    list2=[]
    for r in rows:
        if(r[1]=='php'):
            list1.append(r[0])
        elif(r[1]=='jsp'):
            list2.append(r[0])

    print(len(list1))
    print(len(list2))
    print(list1[:30])
    print(list2[:30])




import os

root = r'C:\Users\86158\Desktop\webshell\train'
path = r'C:\Users\86158\Desktop\webshell\train\train'
files = os.listdir(path)
result = os.path.join(root, 'result')  # 生成最终txt文件(result.txt)的路径
jspCode = os.path.join(root, 'jspCode')  # 生成最终txt文件(result.txt)的路径


# with open(result, 'w', encoding='utf-8-sig') as r:
#     for i in range(0, len(list1)-1):
#         #print(i)
#         #fname = str(i) + '.txt'
#         fname = str(list1[i])
#         filename = os.path.join(path, fname)
#         with open(filename, 'r', encoding='utf-8-sig') as f:
#             for line in f:
#                 r.writelines(line)
#             r.write('\n')

with open(jspCode, 'w', encoding='utf-8-sig') as r:
    for i in range(0, int((len(list2)-1)*0.8)):
        #print(i)
        #fname = str(i) + '.txt'
        fname = str(list2[i])
        filename = os.path.join(path, fname)
        with open(filename, 'r', encoding='utf-8-sig') as f:
            for line in f:
                r.writelines(line)
            r.write('\n')
